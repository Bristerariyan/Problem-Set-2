# Problem Set 2

Start Date and Time| Due Date and Time | Cut-off Date and Time |
---|---|---|
10:50:00 AM on September 20, 2019 | 11:59:59 PM on September 26, 2019 | 12:00:00 AM on October 4, 2019 |

## Recommended Reading 
- Pages 1 – 7, 9, and 10 of [http://www.howstuffworks.com/c.htm](http://www.howstuffworks.com/c.htm).
- Chapters 1 – 5, 9, and 11 – 17 of Absolute Beginner’s Guide to C.
- Chapters 1 – 6 of [Programming in C](https://ptgmedia.pearsoncmg.com/images/9780321776419/samplepages/9780321776419.pdf).

## Problem 2.1: Explore Command-line Interface (CLI)
- Using the terminal app, navigate to the directory `LMSC-261-IntroductionToComputerProgramming/2.IntroductionToCProgrammingLanguage/2.CommandLine+GCC/`.
- You will need to use `cd` and `ls` for navigating.
- Read the [README.md](../2.CommandLine+GCC/README.md) in the 2.CommandLine+GCC folder and try all of commands listed under `Useful commands for the Terminal application`.

## Problem 2.2: Compiling Programs
- Before we can execute (run) a C program, we must *compile* it with a *compiler* (e.g. `gcc`), translating it from *source code* into *machine code* (i.e., zeroes and ones). 
- Execute the command below to do just that:
		
		gcc HelloWorld.c
		
- And then execute `ls` on CLI to see not only `HelloWorld.c` but `a.out` listed in the directory as well. This is because `gcc` has translated the source code in `HelloWorld.c` into machine code in `a.out`, which happens to stand for “assembler output,” but more on that another time.

- Run the program by executing the below:
		
		./a.out

- This should print out `Hello, World` on the CLI display.

## Problem 2.3: Naming Programs
- `a.out` isn’t the most user-friendly name for a program. Let’s compile `HelloWorld.c` again, this time saving the machine code in a file called, more aptly, `HelloWorld`. Execute the below:

		gcc HelloWorld.c -o HelloWorld

- Then executing `ls` on CLI should reveal that not only `HelloWorld.c` (and `a.out` from before) but also `HelloWorld` listed as well.
- This is because `-o` is a *command-line argument*, sometimes known as a *flag* or a *switch*, that tells `gcc` to output (hence the `o`) a file called `HelloWorld`. Execute the below to try out the newly named program:

		./HelloWorld

- This should print out `Hello, World` on the CLI display.

- Follow the instruction on `Compiling and running C code from Command-line Interface` in the [README.md](../2.CommandLine+GCC/README.md) to familiarize yourself more with compiling and running C programs.

## Problem 2.4: Variables
- Create a file named `ProblemSet2.4.c`.
- Write a C program that declares `int`, `float`, and `char` variable. Initialize them to 2019, 0.23f, and 'm'. Print these variable values in reverse order using `printf()`. The printed output should look like this:

		m, 0.23f, 2019

## Problem 2.5: Functions, Variables, and Loops
- Create one file named `ProblemSet2.5.txt` and another called `ProblemSet2.5.c`.
- Write a program that prints out a pyramid that looks like this:

		#
		##
		###
		####
		#####
		######
		#######
		########
		
- Each hash (`#`) is a bit taller than it is wide, so the pyramid itself is also be taller than it is wide.
- Have a variable named `stacks` that decides how tall the pyramid should be for a positive integer between 1 and 8.
- Here's how the program might work when the `stack` variable is `8`:

		$ ./ProblemSet2.4
		#
		##
		###
		####
		#####
		######
		#######
		########

- Here's how the program might work when the `stack` variable is `4`:

		$ ./ProblemSet2.4
		#
		##
		###
		####

- Here's how the program might work when the `stack` variable is `2`:

		$ ./ProblemSet2.4
		#
		##

- Here's how the program might work when the `stack` variable is `1`:

		$ ./ProblemSet2.4
		#

- Start with writing pseudocode on `ProblemSet2.4.txt`. There’s no one right way to write pseudocode, but short English sentences suffice. Odds are your pseudocode will use (or imply using!) one or more functions, conditions, Boolean expressions, loops, and/or variables. Hint:

		1. If height is less than 1 or greater than 8 (or not an integer at all), go back one step
		2. Iterate from 1 through height:
			i. On iteration `i`, print `i` hashes and then a newline

- It’s okay to edit your own after seeing this pseudocode here, but don’t simply copy/paste ours into your own!

- Keep in mind that a hash (`#`) is just a character like any other, so you can print it with `printf`.
- Just as Scratch has a `Repeat` block, so does C have a `for` loop, via which you can iterate some number times. Perhaps on each iteration, `i`, you could print that many hashes?
- You can actually *nest* loops, iterating with one variable (e.g., `i`) in the *outer* loop and another (e.g., `j`) in the *inner* loop. For instance, here’s how you might print a square of height and width `n`, below. Of course, it’s not a square that you want to print :)

```c
for (int i = 0; i < n; i++)
{
    for (int j = 0; j < n; j++)
    {
        printf("#");
    }
    printf("\n");
}
```

## Grading Rubric
Description|Grade
---|---:|
Submitted `ProblemSet2.4.c`, `ProblemSet2.5.txt`, and `ProblemSet2.5.c`.|10%
No compilation warning or error on both `ProblemSet2.4.c` and `ProblemSet2.5.c`.| 10%
Clean, understandable, commented and organized | 10%
Thoroughly documented in *README.md* what the programs do | 20%
Correctly implemented both `ProblemSet2.4.c` and `ProblemSet2.5.c`.| 50%
**Total** | **100%**

## Submission Guideline
- Create a new GitHub project with the right name and problem set number (e.g., `LMSC261-ProblemSet1`).
- Commit and push Scratch files for this problem set into the newly created project.
- Submit the link to the repository on OL to complete the problem set.

## Submission policy:
- All problem set must be first committed and pushed to your GitHub repository. 
- The link to your repository must be submitted to OL to complete the problem set.
- Late projects will incur a penalty of 10% each day.
- Problem sets and projects are due by 11:59:59 pm on the date specified
- After 12:00:00 am (the next day after the due day), your problem sets/projects is one day late (-10%).
- After the next 12: 00:00 am cycle (two days after the due day), your problem sets/projects is two days late (-20%).
- Problem sets and projects will not be accepted after 12:00:00 am at one week after the deadline

---  
**Berklee College of Music**    
Liberal Arts Department  
LMSC-261: Introduction to Computer Programming  
Fall 2019