### Installing Visual Studio Code 
- Download and Install Visual Studio Code from this [URL](https://code.visualstudio.com/Download).
